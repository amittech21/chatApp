const path = require('path');
const express  = require('express');
const http = require('http');
const socketio = require('socket.io');
const Filter  = require('bad-words');
const {generateMessage,generateLocationMessage} = require('./utils/message');
const {addUser,removeUser,getUers,getUserInRoom} = require('./utils/user');

var app = express();

var PORT = process.env.PORT || 3000;
const server = http.createServer(app);
const io = socketio(server);

const publicPath = path.join(__dirname,'public');
app.use(express.static(publicPath));

// app.use(express.static(path.join(__dirname,'public')));

io.on('connection',onConnected);

function onConnected(socket){
    console.log(`Socket connected + ${socket.id}`);

    socket.on('join',(options, callback) => {
        const { error,user } =  addUser({id:socket.id, ...options});

        if(error){
            return  callback(error);
        }

        socket.join(user.room)

        socket.emit('message',generateMessage('Admin','Welcome'));
        socket.broadcast.to(user.room).emit('message', generateMessage('Admin',`${user.username} has joined!`));

        io.to(user.room).emit('roomData',{
            room : user.room,
            users: getUserInRoom(user.room)
        })


        callback();

        //server to client there are threee method
        //socket.emit(specific client) ,io.emit(every),socket.brodcast.emit(every connected except this one)
        //io.to.emit, socket.broadcast.to.emit()

    });

    socket.on('sendMessage', (message, callback) => {
        const user  = getUers(socket.id);
        const filter = new  Filter()

        if(filter.isProfane(message)){
            return callback('Profanity is not allowed');
        }

        io.to(user.room).emit('message', generateMessage(user.username,message))
        callback();
    })

    socket.on('sendLocationdata',(coords,callabck) => {
        const user = getUers(socket.id);
        io.to(user.room).emit('locationMessage',generateLocationMessage(user.username,`https://google.com/maps?q=${coords.latitude},${coords.longitude}`))
        callabck();
    });

    socket.on('disconnect', () => {
        const user  = removeUser(socket.id);

        if(user){
            io.to(user.room).emit('message',generateMessage('Admin',`${user.username} has left!`));
            io.to(user.room).emit('roomData', {
                room : user.room,
                users :getUserInRoom(user.room)
            })
        }
    });
}

server.listen(PORT,() => {
    console.log(`Server running on ${PORT}`);
})