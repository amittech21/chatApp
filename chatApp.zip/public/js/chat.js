const socket =  io();

//Elements
const $messageForm = document.querySelector('#message-form');
const $messageFormInput = document.querySelector('input');
const $messageFormButton = document.querySelector('button');
const $sendLocationButton = document.querySelector('#send-location')
const $messages = document.querySelector('#messages');

//Template
const messageTemplate = document.querySelector('#message-template').innerHTML;
const locationMessageTemplate = document.querySelector('#location-message-template').innerHTML;
const sidebarTemplate = document.querySelector('#side-template');
// const userList = document.getElementById('userList');

function testTheEventListener() {
    console.log(`click on li tags`)
}

function clickUserList(){
    /* document.querySelectorAll('li').forEach(li => {
        li.addEventListener('click', () => {
          testTheEventListener();
        });
    }); */
    console.log('ssssss');
}


 //Qoptions
const { username,room } = Qs.parse(location.search,{ignoreQueryPrefix:true})

const autoScroll = () => {
    //new message element
    const $newMessage = $messages.lastElementChild

    //height of the new message
    const newMessageStyle = getComputedStyle($newMessage)
    const newMessageMargin = parseInt(newMessageStyle.marginBottom);
    const newMessageHeight = $newMessage.offsetHeight  + newMessageMargin;

    //visible height
    const visibleHeight = $messages.offsetHeight

    //Height message container

    const containerHeight = $messages.scrollHeight

    //how far have I scroll?
    const scrollOffset = $messages.scrollTop + visibleHeight

    if(containerHeight - newMessageHeight <= scrollOffset){
        $messages.scrollTop = $messages.scrollHeight;   
    }
}

socket.on('message',(message) => {
    console.log(message);
    const html = Mustache.render(messageTemplate,{
        username:message.username,
        message : message.text,
        createdAt: moment(message.createdAt).format('h:mm a')
    });
    $messages.insertAdjacentHTML('beforeend',html);
    autoScroll();
    clickUserList();
});

socket.on('locationMessage',(message) =>{
    console.log(message,'lcoation')
    const html = Mustache.render(locationMessageTemplate,{
        username:message.username,
        url:message.url,
        createdAt: moment(message.createdAt).format('h:mm a')
    })
    $messages.insertAdjacentHTML('beforeend',html);
    autoScroll();
})

$messageForm.addEventListener('submit',(e)   => {
    e.preventDefault();

    $messageFormButton.setAttribute('disabled','disabled');

    const message = e.target.elements.messageInput.value

    socket.emit('sendMessage', message, (error) => {
        $messageFormButton.removeAttribute('disabled');
        $messageFormInput.value ='';
        $messageFormInput.focus();
        if(error){
            return console.log(error);
        }

        console.log('Message delivered!')
    })
});

/* function submitMessage(e){
    e.preventDefault();

    // const message = document.querySelector('input[name="messageInput"]').value;
    const message = e.target.elements.messageInput.value;

    socket.emit('sendMessage',message, (error) => {
        console.log(`the message was delivered!`);
    })

    socket.emit('sendMessage',message);
} */


$sendLocationButton.addEventListener('click', () => {
    if (!navigator.geolocation) {
        return alert('Geolocation is not supported by your browser.')
    }

    $sendLocationButton.setAttribute('disabled','disabled');

    navigator.geolocation.getCurrentPosition((position) => {
        socket.emit('sendLocationdata', {
            latitude: position.coords.latitude,
            longitude: position.coords.longitude
        }, () => {
            $sendLocationButton.removeAttribute('disabled');
            console.log('Location shared!')  
        })
    })
})

socket.on('roomData',({room,users}) => {
    const userShow =[];
    users.forEach((elem) => {
        userShow.push({
            id: elem.id,
            username: elem.username.toUpperCase(),
            room: elem.room.toUpperCase()
        })
    })
    console.log(userShow,'userShow')
    /* const html = Mustache.render(sidebarTemplate,{
        room,
        users: userShow
    }); */
    {/* <h2 class="room-title">{{room}}</h2>
        <h3 class="list-title">Users</h3>
            <ul class="users" id="userList">
                {{#users}}
                    <li><a data-id={{id}}>{{username}}</a></li>
                {{/users}}
            </ul> */}
    var   html    = `<h2 class="room-title">${room}</h2>
                        <h3 class="list-title">Users</h3>
                        <ul class="users" id="userList">`;
    users.forEach((elem) => {
        html += `<li><a data-id=${elem.id}>${elem.username}</a></li>`;
    });
    html    += `</ul>`;
    document.querySelector('#sidebar').innerHTML = html;
})



/* function sendLocation(e) {
    e.preventDefault();
    
    if(!navigator.geolocation){
        return alert('Geolocation is not support by your browser');
    }

    navigator.geolocation.getCurrentPosition((position) => {
        socket.emit('sendLocationdata',{
            latitude    :   position.coords.latitude,
            longitude   :   position.coords.longitude
        })
        // console.log();
    })
} */

socket.emit('join',{username,room},(error) => {
     if(error){
         alert(error);
         location.href = '/'
     }
})