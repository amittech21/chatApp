/* var app = require('express')();
var http = require('http').Server(app);
var io = require('socket.io')(http); */

const express = require('express');
const app = express();
const http = require('http');
const server = http.createServer(app);
const { Server } = require("socket.io");
const io = new Server(server);
const path = require('path');

const PORT = process.env.PORT || 3000;

/* app.get('/', (req, res) => {
    res.sendFile(__dirname + '/index.html');
}); */

app.use(express.static(path.join(__dirname,'public')));

//Whenever someone connects this gets executed
// io.on('connection', (socket) => {
    // console.log('a user connected');
    /* socket.on('clientEvent', (msg) => {
        console.log('message: ' + msg);
    }); */
    
//   });
/* var clients = 0;
io.on('connection', (socket) => {
    clients++;
    // console.log(socket.connected,'socket',socket.disconnected);
    socket.on('clientEvent', (msg) => {
        // io.emit('broadcast',{description : clients + 'Clients connected'});
        socket.emit('newclientconnect',{ description: 'Hey, welcome!'});
        socket.broadcast.emit('newclientconnect',{ description: clients + ' clients connected!'})
        io.emit('clientEvent', msg);
    });
    socket.on('disconnect', () => {
        clients--;
        // io.emit('broadcast',{description :clients + 'Clients connected'});
        socket.broadcast.emit('newclientconnect',{ description: clients + ' clients connected!'})
        console.log('user disconnected');
    });
}); */

users = [];
console.log(users,'users');
io.on('connection', function(socket) {
    console.log('A user connected');
    socket.on('setUsername', function(data) {
        console.log(users.indexOf(data) > -1,'dataa',users);
        if(users.indexOf(data) > -1) {
        // if(!users.includes(data)){
            console.log('user exist');
            socket.emit('userExists', data + ' username is taken! Try some other username.');
        } else {
            console.log('push methis');
            users.push(data);
            socket.emit('userSet', {username: data});
        }
    });
    socket.on('msg', function(data) {
        //Send message to everyone
        io.sockets.emit('newmsg', data);
    })
});

  server.listen(PORT, function() {
   console.log(`listening on *:${PORT}`);
});

